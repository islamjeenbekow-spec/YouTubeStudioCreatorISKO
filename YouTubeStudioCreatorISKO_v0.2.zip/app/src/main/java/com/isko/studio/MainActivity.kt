package com.isko.studio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IskoApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IskoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var musicUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var captions by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Выбери видео, чтобы начать.") }
    var listening by remember { mutableStateOf(false) }
    var trimStart by remember { mutableFloatStateOf(0f) }
    var trimEnd by remember { mutableFloatStateOf(60f) }
    var speed by remember { mutableFloatStateOf(1f) }
    var textSize by remember { mutableFloatStateOf(24f) }
    var textPosition by remember { mutableFloatStateOf(0.8f) }
    var textColor by remember { mutableStateOf("Белый") }
    var filter by remember { mutableStateOf("Без фильтра") }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        videoUri = uri
        status = if (uri != null) "Видео выбрано. Настрой параметры монтажа ниже." else "Видео не выбрано."
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        musicUri = uri
        if (uri != null) status = "Музыка выбрана."
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) runDictation(context, { listening = it }, { text ->
            captions = listOf(captions.trim(), text.trim()).filter { it.isNotBlank() }.joinToString(" ")
            status = "Текст распознан с микрофона. Проверь его."
        }, { status = it })
        else status = "Нужно разрешить доступ к микрофону."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFFF4B55),
        background = Color(0xFF10131A),
        surface = Color(0xFF1A202B)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("ISKO Creator")
                        Text("YouTube Shorts Studio · версия 0.2", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Создай вертикальный ролик", style = MaterialTheme.typography.headlineSmall)
                Box(
                    Modifier.fillMaxWidth().height(250.dp)
                        .background(Color(0xFF293244), RoundedCornerShape(18.dp)).padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (videoUri == null) "ПРЕДПРОСМОТР 9:16" else "ВИДЕО ВЫБРАНО ✓",
                            color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Text(captions.ifBlank { "Здесь будет текст субтитров" },
                            color = if (textColor == "Жёлтый") Color.Yellow else Color.White,
                            fontSize = androidx.compose.ui.unit.TextUnit(textSize, androidx.compose.ui.unit.TextUnitType.Sp),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = (textPosition * 20).dp)
                        )
                    }
                }

                Text("1. Файлы", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { videoPicker.launch("video/*") }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.VideoFile, null); Spacer(Modifier.width(8.dp))
                    Text(if (videoUri == null) "Выбрать видео" else "Заменить видео")
                }
                OutlinedButton(onClick = { musicPicker.launch("audio/*") }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.MusicNote, null); Spacer(Modifier.width(8.dp))
                    Text(if (musicUri == null) "Добавить музыку" else "Заменить музыку")
                }

                HorizontalDivider()
                Text("2. Обрезка", style = MaterialTheme.typography.titleMedium)
                Text("Начало: ${trimStart.toInt()} сек.")
                Slider(value = trimStart, onValueChange = { trimStart = it.coerceAtMost(trimEnd - 1f) }, valueRange = 0f..300f)
                Text("Конец: ${trimEnd.toInt()} сек.")
                Slider(value = trimEnd, onValueChange = { trimEnd = it.coerceAtLeast(trimStart + 1f) }, valueRange = 1f..600f)

                Text("3. Скорость: ${"%.2f".format(speed)}×", style = MaterialTheme.typography.titleMedium)
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.5f..2f)

                Text("4. Фильтр", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Без фильтра", "Ч/Б", "Тёплый").forEach { item ->
                        FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item) })
                    }
                }

                HorizontalDivider()
                Text("5. Субтитры и текст", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = captions, onValueChange = { captions = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Текст на видео") }, minLines = 3
                )
                Button(
                    onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            runDictation(context, { listening = it }, { captions = listOf(captions, it).filter(String::isNotBlank).joinToString(" "); status = "Текст надиктован." }, { status = it })
                        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    enabled = !listening, modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp))
                    Text(if (listening) "Слушаю…" else "Надиктовать текст")
                }
                Text("Размер текста: ${textSize.toInt()}")
                Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 14f..40f)
                Text("Положение текста")
                Slider(value = textPosition, onValueChange = { textPosition = it }, valueRange = 0f..1f)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = textColor == "Белый", onClick = { textColor = "Белый" }, label = { Text("Белый") })
                    FilterChip(selected = textColor == "Жёлтый", onClick = { textColor = "Жёлтый" }, label = { Text("Жёлтый") })
                }

                HorizontalDivider()
                Text("6. Экспорт", style = MaterialTheme.typography.titleMedium)
                Button(onClick = {
                    status = "Настройки сохранены в редакторе. Экспорт MP4 ещё нужно подключить."
                }, enabled = videoUri != null, modifier = Modifier.fillMaxWidth()) {
                    Text("Подготовить Shorts")
                }
                Text("Статус: $status", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "Прототип 0.2: выбор файлов и настройки интерфейса работают. " +
                    "Параметры обрезки, фильтра, скорости и текста пока не применяются к экспортируемому файлу. " +
                    "Диктовка — с микрофона, не расшифровка звуковой дорожки видео.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun runDictation(
    context: android.content.Context,
    setListening: (Boolean) -> Unit,
    onText: (String) -> Unit,
    onError: (String) -> Unit
) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
        onError("На устройстве нет доступной службы распознавания речи.")
        return
    }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    setListening(true)
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { setListening(false) }
        override fun onError(error: Int) {
            setListening(false); onError("Не удалось распознать речь. Попробуй ещё раз."); recognizer.destroy()
        }
        override fun onResults(results: Bundle?) {
            setListening(false)
            val result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (result != null) onText(result) else onError("Речь не распознана.")
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }
    recognizer.startListening(intent)
}
